from django.contrib import admin

from core.models import Material

# Register your models here.
admin.site.register(Material)
